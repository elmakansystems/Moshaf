const err = ()=>(`
    <header>
        <center>
            <h1> هذة الصفحة غير متاحة </h1>
        </center>
    </header>

`)
module.exports =  err