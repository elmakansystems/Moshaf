
    const header = (name) =>
    `
    <header>
      <center>
         <h1 class="name">${name}</h1>
      </center>
     </header>
    `;
    export default header