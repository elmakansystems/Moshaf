import hide from "../loader.js";
import nav from "../nav.js";
import surah from "./link.js"
import footer from "../footer.js"
import color, { localTheme } from "./bg.js";

const getData = async () => {
    const container = document.querySelector(".container");
    try {
        const apiData = await fetch("https://api.alquran.cloud/v1/surah");
        const { data } = await apiData.json();
        if(data){
        document.querySelector("#nav").innerHTML += nav()
        document.querySelector("#nav").style.top = "0"
        document.querySelector("#footer").innerHTML += footer()
        hide()
        data.map((d) => {
            return (container.innerHTML += surah(d.number, d.name));
          });
          localTheme()
          color()
          return data;
    }
  } catch (error) {
    console.log(error);
  }
};


export default getData