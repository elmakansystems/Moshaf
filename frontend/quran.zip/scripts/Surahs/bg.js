const color = ()=>{
    let changeHandler = (e)=>{
        let cards = document.querySelectorAll("[data-theme]")
        window.localStorage.setItem("data-theme" , e) 
        looper(cards , e)
      }
    const btn = document.getElementById("color-theme")
    btn.addEventListener("change" , e =>changeHandler(e.target.value))
}
export default color

export const localTheme = ()=>{
    let color =  window.localStorage.getItem("data-theme")
    let cards = document.querySelectorAll("[data-theme]")
     document.getElementById("color-theme").value = color
     looper(cards , color)
}

const looper = (data , color)=>{
    data.forEach(d=>{
        d.style.backgroundColor = color
        d.style.color = "#fff"
    })
}