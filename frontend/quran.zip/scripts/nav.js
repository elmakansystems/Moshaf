const nav = ()=>(`
<nav>
    <div class="container">
        <div class="row">
            <div class="logo">
                <div class="row">
                    <img src="./favicon.svg">
                    <span>
                        المصحف المشرف
                    </span>
                </div>
            </div>
          <div class='row'>
          <div class="links">
          <div class="row">
              <a href="/" class="nav__link">الرئيسية</a>
          </div>
      </div>
      <div class="theme">
           <div class="row">
                <input id="color-theme" type="color" value="#0e4600"/>
                <label dir="rtl"> اختر اللون</label>
           </div>
        </div>
    </div>
</nav>
`)

export default nav