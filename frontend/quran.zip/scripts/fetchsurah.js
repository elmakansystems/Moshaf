import footer from "./footer.js";
import hide from "./loader.js";
import nav from "./nav.js";
import color, { localTheme } from "./Surahs/bg.js";
const getSurah = async () => {
    let id = window.location.href.split("?")[1]
    let quranContainer = document.querySelector(".quran-container")
    try {
      const apiData = await fetch(`https://api.alquran.cloud/v1/surah/${id}`);
      const {data}  = await apiData.json();
      if(data){
        hide()
        document.querySelector("#nav").innerHTML += nav()
        document.querySelector("#nav").style.top = "0"
        document.querySelector("#footer").innerHTML += footer()
        return data;
        }
    } catch (error) {
      console.log(error.message);
      quranContainer.innerHTML += `
        <h1>
            البيانات غير صحيحة    
        </h1>
      `
    }
    };

export default getSurah
