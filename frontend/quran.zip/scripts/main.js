
import fetch from "./Surahs/fetch.js"
window.onload =()=>{
    fetch()



}