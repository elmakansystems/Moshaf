import getSurah from "./fetchsurah.js";
import surah from "./singleSurah.js";
import color, { localTheme } from "./Surahs/bg.js";
let quranContainer = document.querySelector(".quran-container")
const displaySurah = async () =>{
  const surahData = await getSurah()
  let {  name , revelationType , ayahs} = surahData
  quranContainer.innerHTML += surah(  name , revelationType , ayahs)
  localTheme()
  color()

}

export default displaySurah