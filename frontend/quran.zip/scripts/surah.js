import displaySurah from "./displaySurah.js";
import { localTheme } from "./Surahs/bg.js";

window.onload=()=>{
  displaySurah()
}


