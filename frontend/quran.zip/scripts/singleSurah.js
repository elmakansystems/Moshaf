const surah = (  name , type , ayahs )=>{
    document.title = ` المصحف |  ${name} ` 
   let ayas = ""
   ayahs.map((a , i)=>{
            ayas+= `
                <div class="aya-line" data-aya="${i+1}">
                    ${a.text}<span class="number" data-theme>${i+1}</span>
                </div>
               `
           })
        
   return(   
   `
        <div class="surah">
            <header class="surah__name" data-theme>
                    <center>
                        <h1 dir="rtl">${name} ${type==="Medinan" ? "مدنية" : "مكية"}</h1>
                    </center>
             </header>
             <div class="surah__body just">
                ${ayas}
             </div>
        </div>
   `)}
export default surah   