const footer = ()=>(
    `
    <div class="container" dir="rtl">
            <center> 
                <h3>تم بفضل الله في 2021 بواسطة   <a  class="footer-link" href="https://www.facebook.com/elmakansystems" target="_blank">Elmakn-Systems</a></h3>
            </center>
    </div>
    `
)
export default footer