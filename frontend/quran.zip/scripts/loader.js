const hide = ()=>{
    document.querySelector(".loader").style.display="none"
   } 
export default hide